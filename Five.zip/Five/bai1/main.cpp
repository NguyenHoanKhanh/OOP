#include "company.cpp"
#include "employee.cpp"
#include "office.cpp"
#include "product.cpp"

int main() 
{
    company cm;
    cm.Input();
    cm.Output();
    cm.Tong_luong();
    cm.Cao_Nhat();
    cm.Thap_Nhat();
    cm.Sap_xep();
    return 0;
}