#include "de.h"

de::de(string keu)
{
    this->Tieng_De = keu;
}

void de::Keu()
{
    cout<<"Tieng keu cua de la : BE BE BE BE !!!"<<endl;
}