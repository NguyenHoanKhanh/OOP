#include "cuu.h"

cuu::cuu(string keu)
{
    this->Tieng_Cuu = keu;
}

void cuu::Keu()
{
    cout<<"Tieng keu cua cuu la : BEEEE BEEEEE !!!"<<endl;
}