bool operator!=(const CNgay &other)
    // {
    //     if (ngay != other.ngay || thang != other.thang || nam != other.nam)
    //     {
    //         return true;
    //     }
    //     else return false;
    // }

    // bool operator==(const CNgay &other)
    // {
    //     if (ngay == other.ngay && thang == other.thang && nam == other.nam)
    //     {
    //         return true;
    //     }
    //     else return false;
    // }

    // bool operator>(const CNgay &other)
    // {
    //     if (nam > other.nam)
    //         return true;
    //     else if (nam < other.nam)
    //         return false;
    //     else {
    //         if (thang > other.thang)
    //             return true;
    //         else if (thang < other.thang)
    //             return false;
    //         else {
    //             if (ngay > other.ngay)
    //                 return true;
    //             else
    //                 return false;
    //         }
    //     }
    // }

    // bool operator<(const CNgay &other) 
    // {
    //     if (nam < other.nam)
    //         return true;
    //     else if (nam > other.nam)
    //         return false;
    //     else {
    //         if (thang < other.thang)
    //             return true;
    //         else if (thang > other.thang)
    //             return false;
    //         else {
    //             if (ngay < other.ngay)
    //                 return true;
    //             else
    //                 return false;
    //         }
    //     }
    // }

    // bool operator>=(const CNgay &other) 
    // {
    //     if (nam > other.nam)
    //         return true;
    //     else if (nam < other.nam)
    //         return false;
    //     else {
    //         if (thang > other.thang)
    //             return true;
    //         else if (thang < other.thang)
    //             return false;
    //         else {
    //             if (ngay >= other.ngay)
    //                 return true;
    //             else
    //                 return false;
    //         }
    //     }
    // }

    // bool operator>(const CNgay &other) 
    // {
    //     if (nam < other.nam)
    //         return true;
    //     else if (nam > other.nam)
    //         return false;
    //     else {
    //         if (thang < other.thang)
    //             return true;
    //         else if (thang > other.thang)
    //             return false;
    //         else {
    //             if (ngay <= other.ngay)
    //                 return true;
    //             else
    //                 return false;
    //         }
    //     }
    // }