#include "bo.h"

bo::bo(string keu)
{
    this->Tieng_Bo = keu;
}

void bo::Keu()
{
    cout<<"Tieng keu cua bo la : UM BO UM BO !!!!"<<endl;
}